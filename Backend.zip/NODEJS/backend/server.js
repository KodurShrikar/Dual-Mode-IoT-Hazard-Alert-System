const mqtt = require('mqtt');
const axios = require('axios');

const mqttClient = mqtt.connect('mqtt://broker.emqx.io');
const topic = 'testtopic/sender';

mqttClient.on('connect', () => {
  console.log('MQTT connected');
  mqttClient.subscribe(topic, (err) => {
    if (err) {
      console.error('Subscription error:', err);
    }
  });
});

mqttClient.on('message', async (topic, message) => {
  console.log(`Message received on topic ${topic}: ${message.toString()}`);

  const data = JSON.parse(message.toString());
  const { alert, latitude, longitude } = data;

  if (alert) {
    try {
      const response = await axios.get(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=AIzaSyBgwc9E4iZkKGVosd7L0OnmmC9NCUHwxJ8`);
      console.log('Location data:', response.data);
    } catch (error) {
      console.error('Error fetching location data:', error);
    }
  }
});
